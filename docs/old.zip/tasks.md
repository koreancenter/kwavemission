# 🚀 케이웨이브 미션(K-Wave Mission) 웹사이트 제작 Tasks

본 문서는 VS Code, Copilot Pro 및 AI 개발 에이전트가 케이웨이브 미션 공식 홈페이지를 단계별로 구축하기 위해 참조하는 작업 가이드입니다.

---

## 📌 프로젝트 핵심 원칙 (Architecture & Design Principles)

1. **Zero-DB & Cost-Effective**: Firebase/Supabase 없이 HTML5 + Tailwind CSS + Vanilla JS + Markdown으로만 구축
2. **No User Auth / Form-Free**: 회원가입 및 DB 연동 폼 삭제. 모든 문의/신청 CTA는 **카카오톡 채널 (`koreancenter`)** 및 **이메일 (`admin@kwavemission.org`)**로 직접 연결.
3. **Gen-Z Targeted Minimalism**: 고대비 타이포그래피, 여백의 미, 고품격/전문성 반영 tone&manner, 절제된 마이크로 애니메이션을 통한 트렌디한 감각.
4. **Markdown Blog Engine**: DB 없이 `posts/` 폴더 내 Markdown 파일 및 JSON Index만으로 주간 선교 소식 게시판 구동.

---

## 🛠️ Task Checklist

### Phase 1. 기본 환경 설정 및 글로벌 디자인 시스템 (Design Constitution)

- [  ] **Task 1.1: 프로젝트 디렉토리 구조 생성**
  - `index.html`, `about.html`, `ministries.html`, `action.html`, `news.html`
  - `/assets` (`/css`, `/js`, `/images`)
  - `/posts` (Markdown 블로그 포스트 보관용) 및 `posts.json`
- [  ] **Task 1.2: Tailwind CSS (CDN or Standalone CLI) 및 Noto Sans KR / Inter 폰트 설정**
- [  ] **Task 1.3: 브랜드 컬러 및 디자인 토큰 정의 (`tailwind.config.js` 또는 Custom CSS)**
  - Primary: Deep Navy/Slate (`#0F172A`)
  - Accent: K-Wave Orange/Red (`#E11D48` 또는 로고 매칭 포인트 칼라)]
  - Background: Warm Off-White (`#F8FAFC`)
- [  ] **Task 1.4: Vibe Prompt & Design Constitution 문서 작성**
  - Copilot 에이전트가 참조할 스타일 가이드라인 확립.

---

### Phase 2. 공통 컴포넌트 & 마크다운 블로그 엔진 개발

- [  ] **Task 2.1: 미니멀 헤더/네비게이션바 (GNB) 구현**
  - 로고 + [소개 | 사역 | 동역 | 소식] + 카카오톡 상담 CTA 버튼
  - 모바일 반응형 슬라이딩/오버레이 메뉴 구현
- [  ] **Task 2.2: 푸터 (Footer) 구현**
  - 단체 정보 (비영리 고유번호, 주소, 대표자, 후원계좌)
  - 카카오톡 채널 링크, 이메일 링크, SNS 아이콘
- [  ] **Task 2.3: DB-Free Markdown 블로그 파서 개발 (`assets/js/blog-engine.js`)**
  - `Marked.js` 라이브러리를 사용해 `.md` 파일 파싱.
  - `posts.json`을 통해 최신 선교 소식 목록 불러오기 & 카테고리 필터링 구현.

---

### Phase 3. 주요 페이지 레이아웃 및 콘텐츠 구현

#### 3.1 메인 페이지 (`index.html`)

- [  ] **Hero Section**: 강렬한 메시지 ("한류의 물결을 넘어, 하나님 나라의 물결로/ 주의 도를 땅 위에")
- [  ] **Core Value & Vision**: "하나님 나라를 위한 한류" 핵심 패러다임 요약
- [  ] **Three Key Pillars (3대 핵심 사역)**:
  1. 영혼을 구하는 일 (관계 개발 사역)
  2. 교회를 세우는 일 (현지 교회 강화 & 타문화권 선교학교)
  3. 세상을 바꾸는 일 (미래 교육 & ODA/정부 지원사업)
- [  ] **Quick Action Cards Grid**:
  - 한국어 강사 단기선교 / 호스트 패밀리 10일 살기 / 발리 워크숍 등 6개 주요 참여 카드
- [  ] **Latest Mission News Preview**: `posts.json` 연동 최신 3개 소식 동적 노출

#### 3.2 단체 소개 페이지 (`about.html`)[cite: 1, 7]

- [  ] 케이웨이브 미션의 시작 & 고백과 선언 (사도신경/개혁주의 세계관)
- [  ] 4대 선교 정신: 개척과 도전 / 자주와 능동 / 창의와 혁신 / 전적 헌신과 총력
- [  ] K-WAVE의 3가지 의미 (King's Wave, Kingdom's Wave, Korean Wave)
- [  ] "선교는 교육입니다" - 예수님의 가르침 모델

#### 3.3 사역 안내 페이지 (`ministries.html`)

- [  ] 인도네시아 30여 개 대학 네트워크 & 주요 사역지 맵/그래픽 요소[cite: 1]
- [  ] 대학 내 거점 센터 6대 플랫폼 영역 안내
- [  ] 발리 타문화권 선교학교 (Insight Workshop / Camp / DEEP Mission)

#### 3.4 동역 & 참여 페이지 (`action.html`)

- [  ] **참여 프로그램별 상세 카드 & 카카오톡 direct CTA**
  - 1) 한국어 강사/센터장 지원 (`koreancenter`)
  - 2) 은혜로운 한국생활 10일 살기 호스트 가정 신청
  - 3) 발리 타문화권 선교 워크숍 신청
  - 4) 현지 교회 결연 및 후원 안내 (국민은행 계좌 정보 포함)

#### 3.5 주간 선교 소식 게시판 (`news.html`)

- [  ] 주간 카드 뉴스/블로그 리스트 뷰
- [  ] 상세 포스트 모달(Modal) 또는 파라미터 기반 dynamic Markdown 뷰어 (`news.html?post=2026-03-week1`)

---

### Phase 4. UI/UX 최적화 및 마이크로 인터랙션

- [  ] **Framer Motion 스타일의 Vanilla JS Scroll Reveal 효과 추가** (Intersection Observer 활용)
- [  ] **모바일 터치 최적화** (CTA 버튼 48px 이상 확보)
- [  ] **카카오톡 1:1 상담 둥동형 Quick Floating Button (우측 하단)**

---

### Phase 5. 검증, 성능 최적화 및 배포

- [  ] **Lighthouse 점수 측정**: Performance 95+ / SEO 100 목표 (Zero-DB 특성상 매우 용이)
- [  ] **GitHub Pages 또는 Vercel 무료 호스팅 자동 배포 설정 (GitHub Actions)**
- [  ] **크로스 브라우징 및 모바일 기기 테스트**
