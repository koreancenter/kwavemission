# posts-sample.md

---
title: "2026년 8월 1주차 인도네시아 선교 소식"
date: "2026-08-01"
author: "Centeral Park  대표 선교사"
category: "선교 소식"
thumbnail: "/assets/images/news-thumb-01.jpg"

---

## 하나님 나라를 위한 한류

* 이번 주 인도네시아 현지 대학교에 새로운 센터가 세워졌습니다...
