# 🌊 케이웨이브 미션 (K-Wave Mission) 웹사이트 프로젝트

 **"문화의 물결을 넘어, 하나님 나라의 물결로"** 
 본 프로젝트는 인도네시아 현지 대학교 대상 고등교육선교를 추진하는 **케이웨이브 미션(K-Wave Mission)** 의 공식 전문적, 학술적 Tone& Manner의 고폼질  최신 UI/UX 웹플랫폼 구축 프로젝트입니다.

---

## 📌 Executive Summary

* **Target Audience**: The next generation, Christian youth and college students, overseas mission leaders and sponsoring partners
* **Website Goal**: A **purely information-oriented static website** excluding databases (DB) and sign-up/application forms
* **Core Communication**: 1:1 direct connection centered on KakaoTalk Open Profile/Channel and email integration
* **Design Direction**: Realizing the sophistication of Big Tech by applying the latest technology to create a luxurious and professional feel while highlighting the beauty of simplicity
* **Technology Stack**: HTML5, Tailwind CSS, Pure JavaScript, Markdown (Static Content Storage)
* **AI Development Ecosystem**: Google AI Ecosystem (Gemini, Antigravity) + VS Code / GitHub

---

## 🎯 1. 전략적 프로젝트 컨셉 & 비전

### 1.1 핵심 가치 및 패러다임 Shift

기존의 심각하며 동정적 이미지의 선교 프레임을 벗어나 다음과 같은 이미지를 전달합니다.

* **'왕의 물결(King's Wave / Kingdom's Wave / Korean Wave)'** 이라는 트렌디하고 세련되며 고급스러운 역동적인 브랜드 정체성을 전달합니다.
* 기존 심각하고 동정적인 이미지에서 탈피하여 **하나님 나라의 특사로서의 특권, 지역연구 전문가로서의 전문성**을 강조합니다.

* **가르치시고 (Teaching First)**: 한국어/한국문화 교육을 통한 인격적 관계 형성
* **삶을 변화시키시고 (Life Transformation)**: 지식 전달을 넘어선 청년들의 비전과 삶의 궤적 전환
* **제자로 만드심 (Disciple Making)**: 현지 대학교 기반으로 한 신앙 공동체 세우기

### 1.2 왜 Google AI 생태계인가?

 * **단일 진실 공급원 (SSOT / Grounding)**: NotebookLM 기반의 문서 100% 반영으로 환각(Hallucination) 없는 개발 환경 구축.
* **비용 제로 & 초고속 퍼포먼스**: Firebase, Supabase 등 백엔드 DB 비용을 전면 축소하여 LCP(Lightest Contentful Paint) 1.0초 미만의 초경량 라이브 웹 구현.
* **지속 가능한 유지보수**: Markdown 파일 수정 및 Git Commit만으로 매주 선교 소식이 즉각 업데이트되는 Zero-DB 구조 달성.

---

## 📐 2. 사이트 맵 (Site Structure)

전체 사이트는 단일 페이지 접근성(Single Page Experience)과 세부 마이크로 페이지를 조합한 **최적의 고픔질 럭셔리 UX**를 제공합니다.

/
├── [01. Home] ------------- (/index.html)
│    ├── Hero Section (비전 선언문 & K-Wave 로고 브랜드)
│    ├── 주요 사역 3대 축 (영혼 구원 / 교회 세움 / 세상 변화)
│    └── 최신 선교 소식 피드 (Markdown Auto-Renderer)
│
├── [02. About Us] --------- (/about/index.html)
│    ├── 케이웨이브 미션의 시작 (2011 인도네시아 사역 개척)
│    ├── 우리의 고백과 선언 (개혁주의 기독교 세계관, 사도신경)
│    └── 선교 정신 4대 가치 (개척·도전, 자주·능동, 창의·혁신, 전적 헌신)
│
├── [03. Ministries] ------- (/ministries/index.html)
│    ├── 현지 대학 한국센터 설립 & 운영 (30여 개 대학교 네트워크)
│    ├── 발리 타문화권 선교학교 (Workshop & Camp & Deep Mission)
│    ├── 한국어 강사 / 센터장 파견 사업
│    └── 은혜로운 한국생활 호스트 가정
│
├── [04. News & Blog] ------ (/news/index.html)
│    ├── 매주 발행되는 인도네시아 현지 선교 소식
│    └── /posts/*.md 기반의 자동 인덱싱 게시판
│
└── [05. Partner & Contact] - (/partner/index.html)
├── 국내 협력교회 & 기관 (전국대학교수선교연합회 등)
├── 동역/후원 안내 (기도, 장학금, 오지교회, 재정후원)
└── Direct Connect Button (카카오톡: kwavemission / 이메일: [admin@kwavemission.org])

---

## 🎨 3. K-Wave Mission Design Constitution

### 3.1. Color System

* Primary: Sunset Coral (`#FF6B52`) - 열정과 문화적 친근함
* Secondary: Deep Ocean Navy (`#1E293B`) - 무게감과 신뢰
* Neutral Background: Crisp Soft White (`#FAFAFA`)
* Accent: Warm Gold (`#F59E0B`) - 왕의 물결 (King's Wave)

### 3.2. Typography

* Headings: 'Pretendard', sans-serif (Font-weight: 700/800)
* Body: 'Pretendard', sans-serif (Font-weight: 400/500, Line-height: 1.7)

### 3.3. Layout & Animation

* Layout: Container max-width 1200px, Minimalist padding
* Interaction: Smooth hover scaling (scale-102), Fade-in on scroll
* Mobile First: Responsive grid (1 col on mobile, 3 cols on desktop)

### 3.4 Typography & UI Components

* **Font Family**: `Pretendard`, sans-serif (가장 깔끔하고 현대적인 가독성 제공)
* **Border Radius**: `rounded-2xl` (부드럽고 포용성 있는 카드 레이아웃)
* **Shadow**: `shadow-sm` ~ `shadow-md` (과도한 입체감은 배제)
* **Micro Interactions**: Smooth Hover Scale (`transition-transform duration-300 hover:-translate-y-1`)

---

## ⚡ 4. Technical Architecture (Zero-DB Static Stack)

[Markdown Posts (/posts/*.md)]
│
▼
[JavaScript Fetcher (app.js)] ──(Front-matter Parsing)──► [Tailwind UI Cards Render]
│
▼
[GitHub Pages / Vercel Host] ◄────── [Direct Kakao/Email Action]

### 4.1 데이터베이스 없는 주간 선교 게시판 구현 기법

* `/posts/2026-08-01-mission-news.md` 형태로 마크다운 파일 저장.
* 마크다운 상단에 YAML Front-matter 삽입:

   ```yaml
   ---
   title: "2026년 8월 1주차 인도네시아 선교 소식"
   date: "2026-08-01"
   author: "Centeral Park  대표 선교사"
   category: "선교 소식"
   thumbnail: "/assets/images/news-thumb-01.jpg"
   ---

* 프론트엔드 Pure JS가 index.json 또는 폴더 목록을 fetch()하여 카드형 UI로 변환 렌더링.

---

## 🔮 5. AI Engineering Guidelines (Vibe Prompt & System Instructions)

### 5.1 System Instruction (AI 코딩 전문가/아키텍트 페르소나)

Plaintext
You are the Lead Front-end Architect specializing in  Static Web Design.
Your objective is to build a high-performance, high quality designed,  responsive, zero-database website for 'K-Wave Mission'.

### 5.2 Strict Constraints

* DO NOT use any backend framework, Supabase, Firebase, or SQL databases.
* Use ONLY HTML5, Tailwind CSS (via CDN or Build), Vanilla JavaScript, and Markdown files.
* Every call-to-action (CTA) button must direct users to KakaoTalk (ID: koreancenter) or Email ([admin@kwavemission.org]).
* Maintain strict adherence to the Design Constitution: Primary #1E293B, Accent #F43F5E, Font 'Pretendard'.
* Optimize all images for WebP format and guarantee LCP < 1.2s.

### 5.3 Antigravity & VS Code Vibe Prompt

Plaintext
Build a minimal, highly aesthetic homepage for K-Wave Mission using HTML, Tailwind CSS, and JS.

* Clean typography with large whitespace and rounded-2xl cards.
* Hero section featuring the tagline: "가르치고, 삶을 변화시키고, 제자로 세우는 일."케이웨이브 미션은 한국학 기반 고등교육 선교 전문가 그룹입니다.
* Add three core mission pillars: 영혼을 구하는 일, 교회를 세우는 일, 세상을 바꾸는 일.
* Implement a client-side Markdown reader that fetches local .md files from /posts directory to display weekly mission news dynamically without any backend.
* Ensure all interactive elements trigger direct KakaoTalk or Email actions.

---

## 🛠️ 6. Performance & Quality Control (Negative Constraints)

* ⛔ No Heavy External Libraries: React, Vue 등 무거운 SPA 프레임워크 배제 (Vanilla JS로 초경량화).
* ⛔ No Database Calls: 모든 서버 요청 차단. 보안 위험성 0%.
* ⛔ No Cluttered UI: 한 화면에 3가지 이상의 폰트 Mix 금지. 원색의 자극적인 배경 사용 절대 금지.
* ✅ Direct Communication: 문의 폼 대신 즉시 열리는 카카오톡 일대일 상담 링크 배치.

---

## 📞 7. Contact & Headquarters

* 단체명: 케이웨이브 미션 (K-WAVE MISSION)
* 대표자: Centeral Park 대표 선교사
* 이메일: [admin@kwavemission.org]
* 카카오톡 ID: kwavemission
* 한국 번호: 070-7781-2585
* 현지 본부: 인도네시아 전국 30여 개 대학교
* 한국 본부: 경기도 부천시 원미구 역곡로 19번길 26
