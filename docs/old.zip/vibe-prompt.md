# vibe-prompt.md

* Create an index.html and app.js file for 'K-Wave Mission' following these specification guidelines:

## Hero Section

* Headline: "한류의 물결을 넘어, 하나님 나라의 물결로"
* Subtitle: "가르치고, 삶을 변화시키고, 제자로 세우는 일." 케이웨이브 미션은 한국학 기반 고등교육 선교 전문가 그룹입니다.
* CTA Buttons: "선교 참여하기", "주간 선교 소식"

## 2. About Us Section

* Four Core Values: 개척과 도전, 자주와 능동, 창의와 혁신, 전적 헌신과 총력
* Meaning of K-Wave: King's Wave, Kingdom's Wave, Korean Wave

## 3. Key Programs Grid (3 Cards)

* 영혼을 구하는 일 (관계 사역)
* 교회를 세우는 일 (현지/오지 교회 협력)
* 세상을 바꾸는 일 (미래 교육/장학)

## 4. Participation / Get Involved Section

* 한국어 강사 단기선교사
* 은혜로운 한국생활 (10일 홈스테이 호스트)
* 인도네시아 타문화권 워크숍/비전트립

## 5. Mission News Section (Markdown Reader)

* Dynamically load `/posts/index.json` or fetch `.md` files to render news cards without a database.

## 6. Footer

* Non-Profit Org ID: 106-82-76139
* Email: [admin@kwavemission.org]
* KakaoTalk ID: kwavemission
